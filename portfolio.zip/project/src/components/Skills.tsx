import React from 'react';
import { Code, Database, Palette, Users, BarChart, Globe } from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: 'Web Development',
      icon: Code,
      color: 'blue',
      skills: [
        { name: 'HTML/CSS', level: 90 },
        { name: 'JavaScript', level: 85 },
        { name: 'PHP', level: 80 },
        { name: 'WordPress', level: 75 },
        { name: 'React', level: 70 }
      ]
    },
    {
      title: 'Programming & Algorithms',
      icon: Database,
      color: 'green',
      skills: [
        { name: 'C++', level: 90 },
        { name: 'Java', level: 85 },
        { name: 'Data Structures', level: 88 },
        { name: 'Algorithms', level: 85 },
        { name: 'MySQL', level: 80 }
      ]
    },
    {
      title: 'Content Creation',
      icon: Palette,
      color: 'purple',
      skills: [
        { name: 'Video Editing (CapCut)', level: 90 },
        { name: 'YouTube SEO', level: 85 },
        { name: 'Animation', level: 80 },
        { name: 'Educational Content', level: 95 },
        { name: 'Scriptwriting', level: 85 }
      ]
    },
    {
      title: 'Leadership & Communication',
      icon: Users,
      color: 'orange',
      skills: [
        { name: 'Team Leadership', level: 95 },
        { name: 'Public Speaking', level: 90 },
        { name: 'Project Management', level: 85 },
        { name: 'Mentoring', level: 90 },
        { name: 'Cross-cultural Communication', level: 88 }
      ]
    },
    {
      title: 'Data Analytics (Learning)',
      icon: BarChart,
      color: 'red',
      skills: [
        { name: 'Excel', level: 70 },
        { name: 'SQL', level: 65 },
        { name: 'Python', level: 60 },
        { name: 'Power BI', level: 55 },
        { name: 'Data Visualization', level: 65 }
      ]
    },
    {
      title: 'Languages',
      icon: Globe,
      color: 'indigo',
      skills: [
        { name: 'English', level: 95 },
        { name: 'Amharic (Native)', level: 100 },
        { name: 'Technical Writing', level: 90 },
        { name: 'Academic Writing', level: 85 }
      ]
    }
  ];

  const softSkills = [
    'Empathy & Emotional Intelligence',
    'Self-discipline & Time Management',
    'Adaptability Under Pressure',
    'Strategic Thinking',
    'Problem-solving',
    'Resilience & Perseverance',
    'Cultural Sensitivity',
    'Customer Service Excellence'
  ];

  const certifications = [
    {
      title: 'Web Development Fundamentals',
      status: 'In Progress',
      description: 'HTML, CSS, JavaScript course project'
    },
    {
      title: 'Data Analytics Track',
      status: 'Started July 2025',
      description: 'SQL, Excel, Power BI self-study program'
    },
    {
      title: 'CapCut Professional Editing',
      status: 'Completed',
      description: 'Advanced video editing and animation techniques'
    },
    {
      title: 'Cabin Crew Training Preparation',
      status: 'Applied',
      description: 'Ethiopian Airlines application submitted'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: { bg: 'bg-blue-100', text: 'text-blue-600', bar: 'bg-blue-600' },
      green: { bg: 'bg-green-100', text: 'text-green-600', bar: 'bg-green-600' },
      purple: { bg: 'bg-purple-100', text: 'text-purple-600', bar: 'bg-purple-600' },
      orange: { bg: 'bg-orange-100', text: 'text-orange-600', bar: 'bg-orange-600' },
      red: { bg: 'bg-red-100', text: 'text-red-600', bar: 'bg-red-600' },
      indigo: { bg: 'bg-indigo-100', text: 'text-indigo-600', bar: 'bg-indigo-600' }
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Skills & Expertise
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A diverse skill set built through continuous learning, practical experience, and determination
          </p>
        </div>

        {/* Technical Skills */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">Technical Skills</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skillCategories.map((category, index) => {
              const colorClasses = getColorClasses(category.color);
              return (
                <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                  <div className="flex items-center mb-6">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${colorClasses.bg} mr-4`}>
                      <category.icon className={`w-6 h-6 ${colorClasses.text}`} />
                    </div>
                    <h4 className="text-lg font-semibold text-gray-900">{category.title}</h4>
                  </div>

                  <div className="space-y-4">
                    {category.skills.map((skill, idx) => (
                      <div key={idx}>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-gray-700">{skill.name}</span>
                          <span className="text-sm text-gray-500">{skill.level}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${colorClasses.bar} transition-all duration-500`}
                            style={{ width: `${skill.level}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Soft Skills */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">Soft Skills</h3>
          <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-200">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {softSkills.map((skill, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0"></div>
                  <span className="text-gray-700 font-medium text-sm">{skill}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Certifications & Learning */}
        <div>
          <h3 className="text-2xl font-bold text-gray-900 mb-8">Certifications & Continuous Learning</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {certifications.map((cert, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-start justify-between mb-3">
                  <h4 className="text-lg font-semibold text-gray-900">{cert.title}</h4>
                  <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                    cert.status === 'Completed' ? 'bg-green-100 text-green-800' :
                    cert.status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
                    cert.status === 'Applied' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-purple-100 text-purple-800'
                  }`}>
                    {cert.status}
                  </span>
                </div>
                <p className="text-gray-600 text-sm">{cert.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Personal Motto */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 border border-blue-200">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Personal Motto</h3>
            <blockquote className="text-xl text-gray-700 font-medium italic mb-2">
              "One Day, One New Skill!"
            </blockquote>
            <p className="text-gray-600">
              "My life is my responsibility. My future is my mission."
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;