import React from 'react';
import { MapPin, Mail, Phone, ExternalLink } from 'lucide-react';

const Hero = () => {
  return (
    <section className="pt-24 pb-16 bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                🌟 Available for Opportunities
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Hi, I'm{' '}
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Addisu Yirdaw
                </span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                A resilient Computer Science student and developer from Ethiopia, 
                transforming challenges into opportunities through code, creativity, and determination.
              </p>
            </div>

            <div className="flex flex-wrap gap-4 text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-blue-600" />
                <span>Debre Berhan, Ethiopia</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-blue-600" />
                <a href="mailto:addisulal@gmail.com" className="hover:text-blue-600 transition-colors">
                  addisulal@gmail.com
                </a>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-blue-600" />
                <span>0980354112</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-4">
              <a
                href="#contact"
                className="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                Get In Touch
              </a>
              <a
                href="https://www.upwork.com/freelancers/~01e4bd5691b71ac766"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors duration-200"
              >
                View Upwork Profile
                <ExternalLink className="w-4 h-4 ml-2" />
              </a>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <h3 className="font-semibold text-gray-900 mb-2">Mission & Vision</h3>
              <blockquote className="text-gray-600 italic">
                "To uplift my family and community through knowledge, digital innovation, and entrepreneurial action. 
                My vision is to become financially free while empowering others through education and accessible technology."
              </blockquote>
            </div>
          </div>

          <div className="relative">
            <div className="relative z-10 bg-white p-8 rounded-2xl shadow-xl border border-gray-200">
              <div className="space-y-6">
                <div className="text-center">
                  <div className="w-32 h-32 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mx-auto mb-4 flex items-center justify-center text-white text-4xl font-bold">
                    AY
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">Addisu Yirdaw</h3>
                  <p className="text-gray-600">Computer Science Student</p>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Current GPA</span>
                    <span className="font-semibold text-gray-900">3.56</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">YouTube Subscribers</span>
                    <span className="font-semibold text-gray-900">135+</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Video Views</span>
                    <span className="font-semibold text-gray-900">2,000+</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Years of Experience</span>
                    <span className="font-semibold text-gray-900">4+</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <p className="text-center text-sm text-gray-600 font-medium">
                    "One Day, One New Skill!"
                  </p>
                </div>
              </div>
            </div>
            
            {/* Background decoration */}
            <div className="absolute -top-4 -right-4 w-72 h-72 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full opacity-10 blur-3xl"></div>
            <div className="absolute -bottom-4 -left-4 w-72 h-72 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-10 blur-3xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;