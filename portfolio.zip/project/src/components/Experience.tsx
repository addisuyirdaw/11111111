import React from 'react';
import { Calendar, MapPin, ExternalLink } from 'lucide-react';

const Experience = () => {
  const experiences = [
    {
      title: 'Student Council Intern & Web Developer',
      company: 'DBU Student Union',
      period: '2025 – Present',
      location: 'Debre Berhan University',
      description: [
        'Building and deploying a full website for the university\'s student council',
        'Integrating secure login systems, admin panels, and club portals',
        'Enhancing UI/UX and deploying on a university-approved domain'
      ],
      technologies: ['PHP', 'MySQL', 'HTML', 'CSS', 'JavaScript'],
      current: true
    },
    {
      title: 'Freelance Video Editor & Educator',
      company: 'YouTube Channel: @adlal-me',
      period: '2024 – Present',
      location: 'Remote',
      description: [
        '135+ subscribers and 2,000+ views with growing engagement',
        'Creates educational content (C++, Python, History) for Ethiopian and international learners',
        'Focused on long-form videos to reach monetization targets (1,000 subs, 4,000 hours)',
        'Specialized in animated educational series using CapCut and AI-enhanced scripting'
      ],
      technologies: ['CapCut', 'YouTube SEO', 'Animation', 'Content Strategy'],
      current: true,
      link: 'https://www.youtube.com/@adlal-me'
    },
    {
      title: 'Private Tutor & Support Worker',
      company: 'Self-employed',
      period: '2021 – Present',
      location: 'Debre Berhan, Ethiopia',
      description: [
        'Teaching coding, mathematics, and English to fellow students',
        'Supporting myself financially through tutoring and various jobs while in school',
        'Developed strong communication and teaching skills',
        'Managed time effectively between studies and work commitments'
      ],
      technologies: ['C++', 'Java', 'Mathematics', 'English'],
      current: true
    }
  ];

  const education = [
    {
      degree: 'BSc in Computer Science',
      institution: 'Debre Berhan University',
      period: 'Third-Year Student',
      gpa: '3.56',
      status: 'In Progress'
    },
    {
      degree: 'BA in Business Administration',
      institution: 'University of the People',
      period: 'Online Program',
      status: 'In Progress'
    }
  ];

  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Experience & Education
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A journey of continuous learning, leadership, and professional growth
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Professional Experience */}
          <div className="lg:col-span-2 space-y-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Professional Experience</h3>
            
            {experiences.map((exp, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <h4 className="text-xl font-semibold text-gray-900">{exp.title}</h4>
                      {exp.current && (
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                          Current
                        </span>
                      )}
                    </div>
                    <div className="flex items-center space-x-4 text-gray-600 mb-2">
                      <span className="font-medium">{exp.company}</span>
                      {exp.link && (
                        <a
                          href={exp.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center text-blue-600 hover:text-blue-700"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      )}
                    </div>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 text-sm text-gray-500 mb-4">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{exp.period}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{exp.location}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <ul className="space-y-2 mb-4">
                  {exp.description.map((item, idx) => (
                    <li key={idx} className="flex items-start space-x-2 text-gray-600">
                      <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2 flex-shrink-0"></span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>

                <div className="flex flex-wrap gap-2">
                  {exp.technologies.map((tech, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 bg-blue-100 text-blue-800 text-sm font-medium rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Education */}
          <div className="space-y-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Education</h3>
            
            {education.map((edu, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-semibold text-gray-900">{edu.degree}</h4>
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">
                      {edu.status}
                    </span>
                  </div>
                  <p className="text-gray-600 font-medium">{edu.institution}</p>
                  <p className="text-gray-500 text-sm">{edu.period}</p>
                  {edu.gpa && (
                    <div className="pt-2 border-t border-gray-200">
                      <span className="text-sm text-gray-600">GPA: </span>
                      <span className="font-semibold text-gray-900">{edu.gpa}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* 2025 Goals */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border border-blue-200">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">2025 Goals</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600 mt-1">🚀</span>
                  <span>Reach YouTube monetization by July 2025</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600 mt-1">💼</span>
                  <span>Build 3+ real-world projects for portfolio</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600 mt-1">📊</span>
                  <span>Master Data Analytics skills by Q4 2025</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600 mt-1">🛫</span>
                  <span>Secure part-time work for experience</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600 mt-1">💻</span>
                  <span>Launch personal website with blog</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;