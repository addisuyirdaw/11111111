import React from 'react';
import { GraduationCap, Heart, Target, Lightbulb } from 'lucide-react';

const About = () => {
  const highlights = [
    {
      icon: GraduationCap,
      title: 'Dual Education',
      description: 'Pursuing Computer Science at Debre Berhan University while studying Business Administration at University of the People'
    },
    {
      icon: Heart,
      title: 'Family Motivation',
      description: 'Driven by love for my mother who raised me with sacrifice, working towards financial freedom for my family'
    },
    {
      icon: Target,
      title: 'Multi-Role Leader',
      description: 'Student leader managing 10+ clubs, educator, developer, content creator, and lifelong learner'
    },
    {
      icon: Lightbulb,
      title: 'Innovation Focus',
      description: 'Building projects that create value in my community through accessible technology and education'
    }
  ];

  const strengths = [
    'Web Development (Frontend & Backend)',
    'Data Structures & Algorithms',
    'Video Editing & Content Creation',
    'Leadership & Communication',
    'Analytical Thinking',
    'Customer Service Excellence'
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            About Me
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From humble beginnings in rural Ethiopia to a mission of empowerment, innovation, and transformation
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          <div className="space-y-6">
            <div className="prose prose-lg text-gray-600">
              <p>
                I'm <strong>Addisu Yirdaw</strong>, a resilient and purpose-driven Computer Science student at 
                <strong> Debre Berhan University</strong>, concurrently studying Business Administration at the 
                <strong> University of the People</strong>. My life journey, rooted in rural Ethiopia, is one of 
                transformation — from humble beginnings to a mission of empowerment, innovation, and financial freedom.
              </p>
              <p>
                As a student leader, educator, developer, video content creator, and lifelong learner, I have worn 
                many hats — not by chance, but by necessity and determination. I thrive in challenging environments, 
                balancing multiple roles daily, and building projects that create value in my community and beyond.
              </p>
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-xl">
              <h3 className="font-semibold text-gray-900 mb-3">What Makes Me Unique?</h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600 mt-1">🌱</span>
                  <span>Started with nothing, building with purpose</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600 mt-1">📚</span>
                  <span>Balancing two degrees while supporting myself</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600 mt-1">💡</span>
                  <span>Driven by the dream to support my mother financially</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600 mt-1">📈</span>
                  <span>Proven track record of growth despite limited resources</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600 mt-1">🤝</span>
                  <span>Serving others while improving myself</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-8">
            <div className="grid sm:grid-cols-2 gap-6">
              {highlights.map((highlight, index) => (
                <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <highlight.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">{highlight.title}</h3>
                  <p className="text-gray-600 text-sm">{highlight.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Core Strengths</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {strengths.map((strength, index) => (
              <div key={index} className="flex items-center space-x-3 bg-white p-4 rounded-lg">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                <span className="text-gray-700 font-medium">{strength}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;