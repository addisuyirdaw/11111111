import React from 'react';
import { ExternalLink, Github, Play, Code, Database, Globe } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: 'DBU Student Council Website',
      description: 'A comprehensive web platform for university student council management with secure authentication, admin panels, and club portals.',
      status: 'In Progress',
      technologies: ['PHP', 'MySQL', 'HTML', 'CSS', 'JavaScript'],
      features: [
        'Secure login system with role-based access',
        'Admin panel for council management',
        'Club registration and management portals',
        'Responsive design for all devices',
        'University-approved domain deployment'
      ],
      icon: Globe,
      color: 'blue'
    },
    {
      title: 'C++ Educational Tool',
      description: 'Interactive educational tool demonstrating fundamental data structures including stacks, queues, and linked lists.',
      status: 'Completed',
      technologies: ['C++', 'Data Structures', 'Algorithms'],
      features: [
        'Visual representation of data structures',
        'Step-by-step algorithm demonstrations',
        'Interactive learning modules',
        'Educational content for students'
      ],
      icon: Code,
      color: 'green'
    },
    {
      title: 'Educational Video Series',
      description: 'Animated educational content series covering programming concepts, exam preparation, and academic success strategies.',
      status: 'Ongoing',
      technologies: ['CapCut', 'Animation', 'YouTube SEO', 'Content Strategy'],
      features: [
        '135+ subscribers and growing',
        '2,000+ total video views',
        'Educational content in C++, Python, History',
        'AI-enhanced scripting and animation',
        'Focus on Ethiopian and international learners'
      ],
      icon: Play,
      color: 'red',
      link: 'https://www.youtube.com/@adlal-me'
    }
  ];

  const upcomingProjects = [
    {
      title: 'Data Analytics Dashboard',
      description: 'Interactive dashboard for data visualization and analysis using modern web technologies.',
      technologies: ['Python', 'SQL', 'Power BI', 'Excel'],
      timeline: 'Q2 2025'
    },
    {
      title: 'Personal Blog Platform',
      description: 'Full-featured blog platform with content management and SEO optimization.',
      technologies: ['React', 'Node.js', 'MongoDB', 'Tailwind CSS'],
      timeline: 'Q3 2025'
    },
    {
      title: 'Mobile Learning App',
      description: 'Educational mobile application for Ethiopian students with offline capabilities.',
      technologies: ['React Native', 'Firebase', 'TypeScript'],
      timeline: 'Q4 2025'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-100 text-blue-600',
      green: 'bg-green-100 text-green-600',
      red: 'bg-red-100 text-red-600',
      purple: 'bg-purple-100 text-purple-600'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-green-100 text-green-800';
      case 'In Progress':
        return 'bg-blue-100 text-blue-800';
      case 'Ongoing':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Projects & Work
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Building meaningful solutions that create value for my community and beyond
          </p>
        </div>

        {/* Current Projects */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">Current Projects</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-lg transition-all duration-200 overflow-hidden">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getColorClasses(project.color)}`}>
                      <project.icon className="w-6 h-6" />
                    </div>
                    <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(project.status)}`}>
                      {project.status}
                    </span>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-xl font-semibold text-gray-900">{project.title}</h4>
                      {project.link && (
                        <a
                          href={project.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-gray-400 hover:text-blue-600 transition-colors"
                        >
                          <ExternalLink className="w-5 h-5" />
                        </a>
                      )}
                    </div>
                    <p className="text-gray-600 text-sm leading-relaxed">{project.description}</p>
                  </div>

                  <div className="mb-4">
                    <h5 className="font-medium text-gray-900 mb-2">Key Features:</h5>
                    <ul className="space-y-1">
                      {project.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start space-x-2 text-sm text-gray-600">
                          <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 flex-shrink-0"></span>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Projects */}
        <div className="bg-gray-50 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">Upcoming Projects</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {upcomingProjects.map((project, index) => (
              <div key={index} className="bg-white rounded-lg p-6 border border-gray-200">
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-gray-900">{project.title}</h4>
                    <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs font-medium rounded-full">
                      {project.timeline}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm">{project.description}</p>
                </div>

                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-6">
            Interested in collaborating on a project or learning more about my work?
          </p>
          <a
            href="#contact"
            className="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors duration-200"
          >
            Let's Work Together
          </a>
        </div>
      </div>
    </section>
  );
};

export default Projects;